package com.example.smartwheels;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.application.isradeleon.notify.Notify;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MyService extends Service {
    String url = "https://smartapi.tricaltech.com/public/api/get";
    Double temp, bp1, bp2, hrate, olevel = null;
    Notify notify;


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("lpg", "onStartCommand: ");
        
//        CreateNotificationChannel();
//
//        Intent intent1 = new Intent(this,MainActivity.class);
//        PendingIntent pendingIntent = PendingIntent.getActivity(this,0,intent1,0);
//        Notification notification = new NotificationCompat.Builder(this,"ChannelID1")
//                .setSmallIcon(R.drawable.disability)
//                .setContentTitle("patient serious Alert ")
//                .setContentText("patient health condition in not good")
//                .setContentIntent(pendingIntent).build();
//
//        startForeground(1,notification);
//        return START_STICKY;
//
        final Handler handler = new Handler();
        Runnable run = new Runnable() {
            @Override
            public void run() {
                Fetch();
                handler.postDelayed(this,10000);
            }
            };
           handler.post(run);

           return super.onStartCommand(intent, flags, startId);
    }


    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("lpg", "onCreate: ");
    }

    @Override
    public void onDestroy() {
        stopForeground(true);
        stopSelf();
        Log.d("lpg", "onCreate: ");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;

    }

    public void Fetch()
    {
        final RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject employee = jsonArray.getJSONObject(i);
                                if (employee != null) {
                                    temp = employee.getDouble("temp");
                                    bp1 = employee.getDouble("bp1");
                                    bp2 = employee.getDouble("bp2");
                                    hrate = employee.getDouble("hrate");
                                    olevel = employee.getDouble("olevel");
                                }
                            }

                            if(temp>38||temp<0||bp1>140||bp1<90||bp2>90||bp2<60||hrate>100||hrate<60||olevel<60||olevel>100)
                            {
                                play();
                                CreateNotification();
                            }
                            //Toast.makeText(MainActivity.this, "data fetch",   Toast.LENGTH_SHORT).show();
                            Log.d("lpg", "Service Running");

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        queue.add(request);
    }

    public void CreateNotification ()
    {
        Notify.build(getApplicationContext())
                .setTitle("Patient Alert")
                .setContent("patient condition is critical")
                .setSmallIcon(R.drawable.helpicon)
                .setColor(R.color.colormehroon)
                .show();
    }

    private MediaPlayer mp = null;

    private void play()
    {
        if(mp==null)
        {
            mp = MediaPlayer.create(getApplicationContext(),R.raw.warningbeep);
            mp.setLooping(true);
            mp.start();
        }

        else if(!mp.isPlaying())
        {
            mp.start();
        }

    }

    private void CreateNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            NotificationChannel channel = new NotificationChannel("ChannelID1", "ForeGround Notification", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
//        else {
//            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "MyNotification")
//                    .setSmallIcon(R.drawable.disability)
//                    .setContentTitle("patient serious Alert ")
//                    .setContentText("patient health condition in not good")
//                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);
//        }
//

    }


}
