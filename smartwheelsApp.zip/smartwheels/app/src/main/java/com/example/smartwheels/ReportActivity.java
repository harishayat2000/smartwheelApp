package com.example.smartwheels;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.navigation.NavigationView;

public class ReportActivity extends AppCompatActivity {

    NavigationView nav;
    ActionBarDrawerToggle toggle;
    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    public void TodayReport(View view) {
        String url = "https://smartapi.tricaltech.com/api/todayreport";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }


    public void WeeklyReport(View view) {
        String url = "https://smartapi.tricaltech.com/api/weeklyreport";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }


    public void MonthlyReport(View view) {
        String url = "https://smartapi.tricaltech.com/api/monthlyreport";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }

    public void GoBack(View view) {
        Intent intent = new Intent(ReportActivity.this,MainActivity.class);
        startActivity(intent);
        this.finish();
    }
}