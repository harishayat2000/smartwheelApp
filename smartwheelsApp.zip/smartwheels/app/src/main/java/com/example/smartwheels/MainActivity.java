package com.example.smartwheels;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;
import com.application.isradeleon.notify.Notify;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
//import com.bumptech.glide.Glide;
import com.application.isradeleon.notify.Notify;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
//import java.io.FileNotFoundException;
import java.io.FileOutputStream;
//import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    TextView temp_view, bp1_view, bp2_view, hrate_view, olevel_view;
    Double temp,bp1,bp2,hrate,olevel = null;
    ImageButton sync_btn,download_btn;
    NavigationView nav;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    androidx.appcompat.widget.Toolbar toolbar;
    //String url = "https://smartapi.tricaltech.com/public/api/get";
    String url = "https://smartapi.tricaltech.com/api/get";
    private MediaPlayer mp = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FetchData();
        Intent intent = new Intent(this,MyService.class);
           // startForegroundService(intent);


           startService(intent);


        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED);

        sync_btn= findViewById(R.id.sync_btn);
        download_btn = findViewById(R.id.download_btn);
        temp_view = findViewById(R.id.temp_view);
        bp1_view = findViewById(R.id.bp1_view);
        bp2_view = findViewById(R.id.bp2_view);
        hrate_view = findViewById(R.id.hrate_view);
        olevel_view = findViewById(R.id.olevel_view);

        Button  stopbtn= (Button)findViewById(R.id.stopbtn);

        stopbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (mp.isPlaying()) {
                        mp.stop();
                        mp.release();
                        mp = null;
                    }
                } catch (Exception e) {

                }
            }
        });

        toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nav =(NavigationView) findViewById(R.id.navmenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);

        toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toggle);

        toggle.syncState();

        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.Home :
                        Toast.makeText(MainActivity.this, "Home panel is open",   Toast.LENGTH_SHORT).show();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.Sync :
                        FetchData();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.Report :
                        report();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.Help :
                        Intent intent = new Intent(MainActivity.this,HelpActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                }
                return true;
            }
        });
    }

    //---------------------------------------------------" JASON PARSE "------------------------------------

    private void FetchData() {
        final RequestQueue queue = Volley.newRequestQueue(this);
        final Handler handler = new Handler();
        Runnable run = new Runnable() {
            @Override
            public void run() {

                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    JSONArray jsonArray = response.getJSONArray("data");
                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        JSONObject employee = jsonArray.getJSONObject(i);
                                        if(employee!=null) {
                                            temp = employee.getDouble("temp");
                                            bp1 = employee.getDouble("bp1");
                                            bp2 = employee.getDouble("bp2");
                                            hrate = employee.getDouble("hrate");
                                            olevel = employee.getDouble("olevel");
                                        }
                                    }
                                    temp_view.setText(String.valueOf(temp));
                                    //bp2_view.setText(String.valueOf(bp2));
                                    if(temp>38||temp<0||bp1>140||bp1<90||bp2>90||bp2<60||hrate>100||hrate<60||olevel<60||olevel>100)
                                    {
                                        play();
                                    }
      //---------------------------------------------------------------------------------------------------------------------
                                    if(temp>=38) {
                                        temp_view.setText(String.valueOf(temp)+"  High");
                                        temp_view.setTextColor(getResources().getColor(R.color.Red));
                                    }
                                    if(temp<=0) {
                                        temp_view.setTextColor(getResources().getColor(R.color.yellow));
                                        temp_view.setText(String.valueOf(temp)+"  low");
                                    }
                                    if(temp<37.2&&temp>28) {
                                        temp_view.setTextColor(getResources().getColor(R.color.Green));
                                        temp_view.setText(String.valueOf(temp)+"  Normal");
                                    }
      //---------------------------------------------------------------------------------------------------------------------
                                    if(bp1>=140){
                                        bp1_view.setTextColor(getResources().getColor(R.color.Red));
                                        bp1_view.setText(String.valueOf(bp1)+"  High");
                                    }
                                    if(bp1<=90){
                                        bp1_view.setTextColor(getResources().getColor(R.color.yellow));
                                        bp1_view.setText(String.valueOf(bp1)+"  low");
                                    }
                                    if(bp1<140&&bp1>90){
                                        bp1_view.setTextColor(getResources().getColor(R.color.Green));
                                        bp1_view.setText(String.valueOf(bp1)+"  Normal");
                                    }
      //--------------------------------------------------------------------------------------------------

                                    if(bp2>=90){
                                        bp2_view.setTextColor(getResources().getColor(R.color.Red));
                                        bp2_view.setText(String.valueOf(bp2)+"  High");
                                    }
                                    if(bp2<=60){
                                        bp2_view.setTextColor(getResources().getColor(R.color.yellow));
                                        bp2_view.setText(String.valueOf(bp2)+"  low");
                                    }
                                    if(bp2<90&&bp2>60){
                                        bp2_view.setTextColor(getResources().getColor(R.color.Green));
                                        bp2_view.setText(String.valueOf(bp2)+"  Normal");
                                    }
     //------------------------------------------------------------------------------------------------------------
                                    if(hrate>=100){
                                        hrate_view.setTextColor(getResources().getColor(R.color.Red));
                                        hrate_view.setText(String.valueOf(hrate)+"  High");
                                    }
                                    if(hrate<=60){
                                        hrate_view.setTextColor(getResources().getColor(R.color.yellow));
                                        hrate_view.setText(String.valueOf(hrate)+"  low");
                                    }
                                    if(hrate<100&&hrate>60){
                                        hrate_view.setTextColor(getResources().getColor(R.color.Green));
                                        hrate_view.setText(String.valueOf(hrate)+"  Normal");
                                    }
     //---------------------------------------------------------------------------------------------------------------------
                                    if(olevel>=100){
                                        olevel_view.setTextColor(getResources().getColor(R.color.Red));
                                        olevel_view.setText(String.valueOf(olevel)+"  High");
                                    }
                                    if(olevel<=60){
                                        olevel_view.setTextColor(getResources().getColor(R.color.yellow));
                                        olevel_view.setText(String.valueOf(olevel)+"  Low");
                                    }
                                    if(olevel<100&&olevel>75){
                                        olevel_view.setTextColor(getResources().getColor(R.color.Green));
                                        olevel_view.setText(String.valueOf(olevel)+"  Normal");
                                    }

                                    Log.d("lpg", "data fetch");
                                    Toast.makeText(getApplicationContext(),"Data Updated",Toast.LENGTH_SHORT).show();

      //-----------------------------------------------------------------------------------------------------------------------

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });
                queue.add(request);
                handler.postDelayed(this,200000);
            }
        };
        handler.post(run);
    }

    //------------------------------------------------------CREATE PDF ----------------------------------------

    private  void report()
    {
        Intent i = new Intent(MainActivity.this,ReportActivity.class);
        startActivity(i);
//        PdfDocument mypdfdoc = new PdfDocument();
//        PdfDocument.PageInfo mypageinfo = new PdfDocument.PageInfo.Builder(210,297,1).create();
//        PdfDocument.Page mypage =  mypdfdoc.startPage(mypageinfo);
//
//        Paint mypaint = new Paint();
//        int x=20,y=25;
//        String tempp = "temprature : "+String.valueOf(temp) +"\nBPup : "+ String.valueOf(bp1)+"\nBPdown : "+String.valueOf(bp2)+"\nHeartrate : "+String.valueOf(hrate)+"\nOxygen level"+String.valueOf(olevel);
//        mypage.getCanvas().drawText(tempp,x,y,mypaint);
/*

        String tempppp = "My name is haris hayat i belong to a country from new so taht sdhaj kjkf kjds jkds kd ";

        for(String line:tempp.split("\n") )
        {
            mypage.getCanvas().drawText(line,x,y,mypaint);
            y+=mypaint.descent()-mypaint.ascent();
        }
*/

//        String myfilepath = Environment.getExternalStorageDirectory().getPath()+"/report.pdf";
//        //this.externalCacheDir!!.absolutePath, "/your_file_name"
//        File myfile = new File(myfilepath);
//
//        mypdfdoc.finishPage(mypage);

//
//        try
//        {
//            mypdfdoc.writeTo(new FileOutputStream(myfile));
//            Toast.makeText(getApplicationContext(),"File Saved",Toast.LENGTH_SHORT).show();
//        }
//        catch (Exception e)
//        {
//            e.printStackTrace();
//            Toast.makeText(getApplicationContext()," Error file saving",Toast.LENGTH_LONG).show();
//
//        }
//        mypdfdoc.close();
//
    }

    //----------------------------------------------------------" Report Generate "  -------------------------------------
    public void Reportgenerate(View view) { report(); }

    //------------------------------------------------------------ " SYNC " ----------------------------------------------
    public void sync(View view) { FetchData(); }

    //------------------------------------------------------------ " Start service " ----------------------------------------------
    public void startsrvice(View view) {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
//        {
//            NotificationChannel channel = new NotificationChannel("MyNotification", "MyNotification", NotificationManager.IMPORTANCE_DEFAULT);
//            NotificationManager manager = getSystemService(NotificationManager.class);
//            manager.createNotificationChannel(channel);
//        }
//        else {
//            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "MyNotification")
//                    .setSmallIcon(R.drawable.disability)
//                    .setContentTitle("patient serious Alert ")
//                    .setContentText("patient health condition in not good")
//                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);
//        }
        Notify.build(getApplicationContext())
                .setTitle("Jill Zhao")
                .setContent("Hi! So I meet you today?")
                .setSmallIcon(R.drawable.helpicon)
                .setLargeIcon("https://images.pexels.com/photos/139829/pexels-photo-139829.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=150&w=440")
                .largeCircularIcon()
                .setPicture("https://images.pexels.com/photos/1058683/pexels-photo-1058683.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
                .setColor(R.color.colorPrimary)
                .show();
    }
    //------------------------------------------------------------ " Stop service " ----------------------------------------------

    public void stopsrvice(View view) {
        Intent intent = new Intent(this,MyService.class);
        stopService(intent);
    }
    //--------------------------------------------------------------" Play beep " ---------------------------------
    private void play()
    {
        if(mp==null)
        {
            mp = MediaPlayer.create(getApplicationContext(),R.raw.warningbeep);
            mp.setLooping(true);
            mp.start();
        }

        else if(!mp.isPlaying())
        {
            mp.start();
        }
    }
}

